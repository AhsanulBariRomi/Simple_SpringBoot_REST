package com.springbootrest.springrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springbootrest.springrest.models.Course;

//JpaRepository < [Model name], [Primary key type] >
public interface CourseDao extends JpaRepository<Course, Long>{
	
}
 