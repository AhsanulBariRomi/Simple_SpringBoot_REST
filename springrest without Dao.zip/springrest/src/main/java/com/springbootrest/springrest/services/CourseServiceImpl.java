package com.springbootrest.springrest.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.springbootrest.springrest.models.Course;

@Service
public class CourseServiceImpl implements CoureseService{
	//Declared a list of course type 
	List<Course> courseList;
	
	/*constructor created. so that whenever we create an object, some courses 
	  will be added to the list by default as there is no DB & Dao layer */
    public CourseServiceImpl() {
		courseList = new ArrayList<>();
		courseList.add(new Course(999,"Java", "Porate ashbe Romi vai"));
		courseList.add(new Course(777,"PL/SQL", "Porate ashbe Legendary Bari vai"));
		courseList.add(new Course(555,"SpringBoot", "Shikhte Ashbe Ahsanul Bari Romi"));
    }

	@Override
	public List<Course> getCourses() {
		return courseList;
	}

	@Override
	public Course getCourse(long courseId) {
		Course c = null;
		for(Course course: courseList) {
			if(course.getId() == courseId) {
				c = course;
				break;
			}
		}
		return c;
	}

	@Override
	public Course addCourse(Course course) {
		courseList.add(course);
		return course;
	}

	@Override
	public Course updateCourse(Course course, long courseId) {
		/*for(Course x: courseList) {
			if(x.getId() == courseId) {
				x.setTitle(course.getTitle());
				x.setDescription(course.getDescription());
			}
		}*/
		
		//Same work using [MAP] function of JAVA STREAM API
		courseList = courseList.stream().map(obj -> {
			if(obj.getId()==courseId) {
				obj.setTitle(course.getTitle());
				obj.setDescription(course.getDescription());
			}
			return obj;
		}).collect(Collectors.toList());
		
		return course;
	}

	@Override
	public void deleteCourse(long courseId) {
		Course c = getCourse(courseId);
	    /* [FILTER] funtion of JAVA STREAM API. if it returns true then the value is kept else false.*/
		courseList = courseList.stream().filter(obj -> {
			if(obj.getId()!=courseId) {
				return true;
			}
			else {
				return false;
			}
		}).collect(Collectors.toList());
	}
	
}
